from django.contrib import admin
from .models import Bot, Session, Task

admin.site.register(Bot)
admin.site.register(Session)
admin.site.register(Task)

# Register your models here.
